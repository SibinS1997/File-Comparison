<!DOCTYPE html>
<html lang="en">
   <head>
      <!--Required Meta tags-->
      <meta charset="utf-8">
      <meta http-equiv="X-UA Compatible" content="IE-Edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!--Bootstrap css-->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
      <!---Fonts Css-->
      <link rel="preconnect" href="https://fonts.gstatic.com">
      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
      <!--Custom Css-->
      <link rel="stylesheet" href="css/style.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <title>Serial Number Checking</title>
   </head>
   <body>

  

      <!--Header start-->
      <nav class="navbar navbar-expand-lg navbar-light bg-light h-140">
         <div class="container">
            <a class="navbar-brand" href="#"><img src="images/Rurutek_Logo_SVG.svg" class="hyper-logo"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
               <ul class="navbar-nav ml-auto">
                  <li class="nav-item active">
                     <a class="nav-link active" href="#">File Comparison <span class="sr-only"></span></a>
                  </li>
                  <li class="nav-item">
                     <a class="nav-link"  class="btn btn-secondary float-right" data-toggle="modal" data-target="#myModal2"> Version Details</a>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
      <!--Header end -->
      <!--Main sec start-->
      <div class="container mt-50">
         <div class="row justify-content-md-center">
            <div class="col-xl-7 col-lg-7  col-md-7 col-sm-12">
               <img src="images/Data Arranging_Flatline.svg" class="left-side-pic" alt="data-arrange">
        
            </div>
            <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12 ml-auto mt-100">
               <div class="card">
                 
               <form  id="formSubmit" action="CheckFile.php" method="post" enctype="multipart/form-data" class="form" autocomplete="off">
                 
                 
                  <div class="card-body text-dark">
                        <h3 class="text-capitalize text-center">File <span>Comparison</span> </h3>
                        <div class=h-50><p class="text-secondary">File 2 - <span class="text-danger">Column A</span> is considered for comparison.</p>
                        </div>
                      <div class="form-group">

                           <div class="file-upload-wrapper" data-text="File with RSN and Mac ID">
                           <input type="file" id="file1" class="file-upload-field">
                            </div>
                        </div>
                        <div class="form-group">
                           <div class="file-upload-wrapper" data-text="File to Compare">
                              <input type="file" id="file2" class="file-upload-field">
                            </div>

                        </div>
                       

                        <div class="btn-groups">
                           <button onclick="resetFile()" class="btn btn-sm btn-clear">Clear</button>
                           <button type="submit" class="btn btn-primary btn-sm btn-convert" >Convert</button>
                          
                        </div>
                     

                                     <p id="converted"> </p>

                  </div>                  
                  </form>
                  <div id="loading" style="display:none;position:relative;top:-300px;left:200px"><img src="images/abc.gif" width="100px">  </div>    <!----   Loading image --->

               </div>
            </div>
         </div>
      </div>
      </div>
      <!--Main sec end-->
      <div class="footer">
         <div class="copyright">
            © Copyright <script>
               document.write(new Date().getFullYear());
            </script><strong> Rurutek Private Limited </strong> All Rights Reserved
         </div>
      </div>

      <!--Popup modal start -->
<!-- Modal -->


        <!--Popup modal end-->
        <!--Version details start-->
           	<!-- Modal -->
	<div class="modal right fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
		<div class="modal-dialog" role="document">
			<div class="modal-content">

				<div class="modal-header">
					<h4 class="modal-title" id="myModalLabel2">Version details</h4>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>

				<div class="modal-body">
               <h6>Version name : <span>1.0</span> </h6>
<h6>Developed by : <span>Rurutek Private Limited </span></h6>
<h6>Features </h6>
       <img src="images/Left -xl-picture.png" class="left-side-pic" alt="data-arrange">


       <h6>How to compare</h6>
       
         <p> Only xlsx and csv files are supported </p>
         <p>The values at Column A of second file are considered for comparison</p>
       
				</div>

			</div><!-- modal-content -->
		</div><!-- modal-dialog -->
	</div><!-- modal -->

        <!--Version details end-->
      <!---Script js start-->
      <script src="js/custom.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>

      <script>
      $(document).ready(function() {
         $('#formSubmit').submit(function(e) {

            e.preventDefault();
      if($('#file1').get(0).files.length ==0 || $('#file2').get(0).files.length ==0)
       {alert("Upload a file")}
else{
       
            
            var fd = new FormData(this);
  fd.append('file1',$('#file1')[0].files[0]);
  fd.append('file2',$('#file2')[0].files[0]);


  $.ajax({
    method:"POST",
    url:"compare.php",    
    data: fd,  
    cache: false,
    contentType: false,
    processData: false,  
    
    beforeSend:function()
    {

$("#formSubmit").css("opacity",".2");

$("#loading").show();

    },
    
    success: function(data){ 
$("#loading").hide();
$("#formSubmit").css("opacity","1");

       
      $("#converted").html(data);
    },
    error: function(xhr, status, error) {
      var err = eval("(" + xhr.responseText + ")");
      console.log(err.Message);
      console.log('xhr: ');
      console.log(xhr);
      console.log('status: ' + status);
      console.log('error: ' + error);
    }
  });
}    
          });
      
      });
   </script>
  


   </body>
</html>