
<?php
require_once 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Csv;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Color;





    $file_mimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

    if (isset($_FILES['file1']['name']) && in_array($_FILES['file1']['type'], $file_mimes)) {

        $arr_file = explode('.', $_FILES['file1']['name']);
        $extension = end($arr_file);

        if ('csv' == $extension) {
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
        } else {
            $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        }

        $spreadsheet = $reader->load($_FILES['file1']['tmp_name']);

        $sheetData1 = $spreadsheet->getActiveSheet()->toArray();
    }


else{echo "file 1 not suits";}
    if (isset($_FILES['file2']['name']) && in_array($_FILES['file2']['type'], $file_mimes)) {

        $arr_file2 = explode('.', $_FILES['file2']['name']);
        $extension2 = end($arr_file2);

        if ('csv' == $extension2) {
            $reader2 = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
        } else {
            $reader2 = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
        }

        $spreadsheet2 = $reader2->load($_FILES['file2']['tmp_name']);

        $sheetData2 = $spreadsheet2->getActiveSheet()->toArray();
    }
else{echo "file 2 not suits";}

error_reporting(0);



    if (!empty($sheetData2)) {


        $array = array();


        for ($i = 0; $i < count($sheetData2); $i++) {

            if ($sheetData2[$i][0] != ""  && substr(trim($sheetData2[$i][0]), 0, 1) !== 'M') { 

                for ($j = 0; $j < count($sheetData1); $j++) {

                        if (in_array(trim($sheetData2[$i][0]), array_map('trim',$sheetData1[$j]))) {



                            $join = join(',', $sheetData1[$j]);

                            for ($k = $i; $k >= 0; $k--) {

                                if (substr(trim($sheetData2[$k][0]), 0, 1)=== 'M') {

                                    break;
                                }
                            }



                            break;
                        }
                    }
                    $explodejoin = explode(",", $join);

                    if (!in_array(trim($sheetData2[$i][0]), array_map('trim',$explodejoin)))
                     {

                        if($k!=-1){array_push($array,array($sheetData2[$k][0], $sheetData2[$i][0],"","","NOT FOUND"));}

                        else{array_push($array,array("",$sheetData2[$i][0] ,"","","NOT FOUND"));}
                    } 
                    
                    
                    else
                     {

                        if($k!=-1) {array_unshift($explodejoin,$sheetData2[$k][0]);array_push($array,$explodejoin) ;}

                        else{array_unshift($explodejoin,"");array_push($array,$explodejoin);}
                    }

                }
            
        }

///  Findiding Duplicate values //

$array_tmp = array();
foreach($array as $k){
        if(!in_array($k, $array_tmp)){
        $array_tmp[]=$k;
        }
        else{
            array_push($k,"Duplicate");$array_tmp[] = $k;}
        
    }


    // Writing in Excel Sheet //

         $header = $array_tmp; 
         $spreadsheet = new Spreadsheet();
         $sheet = $spreadsheet->getActiveSheet();
         $sheet->fromArray($header, NULL, 'A1'); 
         for($m=0; $m<count($array_tmp);$m++)
                    {
                            $cellValue = $spreadsheet->getActiveSheet()->getCellByColumnAndRow(5,$m)->getValue();
                             if($cellValue =='NOT FOUND'){
                            $spreadsheet->getActiveSheet()->getStyle('A'.$m.':E'.$m)->getBorders()
                            ->getOutline()
                            ->setBorderStyle(Border::BORDER_THICK)
                            ->setColor(new Color('FFFF0000'));
                                                         } 
                     }
        $highestRow = $sheet->getHighestRow(); // e.g. 10e
        $highestColumn = $sheet->getHighestColumn(); // e.g 'F'
        $highestColumnIndex = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::columnIndexFromString($highestColumn); // e.g. 5
        for ($row = 1; $row <= $highestRow; ++$row) {
            for ($col = 1; $col <= $highestColumnIndex; ++$col) {
                $value = $sheet->getCellByColumnAndRow($col, $row)->getValue();
                if($value=='Duplicate')
                {
                $column= $sheet->getCellByColumnAndRow($col, $row)->getCoordinate();
                $spreadsheet->getActiveSheet()->getStyle($column)->getFill()
                ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
                ->getStartColor()->setARGB('FFFF00');
                }
              }
        }     
                        header('Content-Type: application/vnd.ms-excel');
                        header('Content-Disposition: attachment;filename="test.xlsx"');
                        header('Cache-Control: max-age=0');
                        header('Cache-Control: max-age=1');
                        header('Cache-Control: cache, must-revalidate');
                        header('Pragma: public');
                        
                        $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
                        $writer->save('File.xlsx');
                         echo '<div class="text-center"><br/>File converted successfully!
 <a href="File.xlsx" name="submit_values" >Download</a></div>';
    }



?>

